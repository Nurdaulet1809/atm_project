from setuptools import setup

setup(name='vsearch',description='vowel search tool',py_modules=['vsearch'])